
ESX = nil

Citizen.CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Citizen.Wait(0)
    end
end)

RegisterCommand('callmechanic', function()
    local coords = GetEntityCoords(PlayerPedId())
    TriggerServerEvent('esx_mechanicjob:requestMechanic', coords)
    ESX.ShowNotification("Permintaan mekanik dikirim.")
end, false)

function OpenUpgradeMenu()
    local elements = {
        {label = 'Mesin (Level 4)', value = 'engine'},
        {label = 'Rem (Level 2)', value = 'brakes'},
        {label = 'Turbo', value = 'turbo'},
        {label = 'Suspensi (Level 4)', value = 'suspension'}
    }

    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'upgrade_menu', {
        title = 'Upgrade Kendaraan',
        align = 'top-left',
        elements = elements
    }, function(data, menu)
        local vehicle = GetVehiclePedIsIn(PlayerPedId(), false)
        if vehicle == 0 then
            ESX.ShowNotification("Kamu harus berada dalam kendaraan.")
            return
        end

        local mod = data.current.value

        if mod == 'engine' then
            SetVehicleMod(vehicle, 11, 3, false)
            ESX.ShowNotification("Mesin di-upgrade ke level 4.")
        elseif mod == 'brakes' then
            SetVehicleMod(vehicle, 12, 1, false)
            ESX.ShowNotification("Rem di-upgrade.")
        elseif mod == 'turbo' then
            ToggleVehicleMod(vehicle, 18, true)
            ESX.ShowNotification("Turbo diaktifkan.")
        elseif mod == 'suspension' then
            SetVehicleMod(vehicle, 15, 3, false)
            ESX.ShowNotification("Suspensi diturunkan.")
        end

        menu.close()
    end, function(data, menu)
        menu.close()
    end)
end

Citizen.CreateThread(function()
    while true do
        Wait(0)
        local playerCoords = GetEntityCoords(PlayerPedId())
        
        if #(playerCoords - vector3(-211.55, -1324.55, 30.89)) < 10 then
            DrawMarker(27, -211.55, -1324.55, 30.89-0.95, 0, 0, 0, 0, 0, 0, 1.5, 1.5, 1.0, 0, 150, 255, 100, false, true, 2, false, false, false, false)

            if #(playerCoords - vector3(-211.55, -1324.55, 30.89)) < 2.0 then
                ESX.ShowHelpNotification("Tekan ~INPUT_CONTEXT~ untuk membuka menu servis.")
                if IsControlJustReleased(0, 38) then
                    OpenUpgradeMenu()
                end
            end
        end
    end
end)

function RaiseCar()
    local vehicle = GetVehiclePedIsIn(PlayerPedId(), false)
    if vehicle == 0 then
        ESX.ShowNotification("Naik ke dalam kendaraan dulu.")
        return
    end

    local pos = GetEntityCoords(vehicle)
    for i = 1, 10 do
        SetEntityCoords(vehicle, pos.x, pos.y, pos.z + 0.1)
        Wait(150)
    end
    ESX.ShowNotification("Kendaraan berhasil diangkat.")
end
