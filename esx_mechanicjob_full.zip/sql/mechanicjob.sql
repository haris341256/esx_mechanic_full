
-- Add the necessary tables and fields for society_mechanic
CREATE TABLE IF NOT EXISTS `addon_account` (
    `name` VARCHAR(64) NOT NULL,
    `label` VARCHAR(64) NOT NULL,
    `shared` INT(11) NOT NULL DEFAULT 0,
    PRIMARY KEY (`name`)
);

INSERT INTO `addon_account` (name, label, shared) VALUES
('society_mechanic', 'Mechanic', 1);

CREATE TABLE IF NOT EXISTS `datastore` (
    `name` VARCHAR(64) NOT NULL,
    `label` VARCHAR(64) NOT NULL,
    `shared` INT(11) NOT NULL DEFAULT 0,
    PRIMARY KEY (`name`)
);

INSERT INTO `datastore` (name, label, shared) VALUES
('society_mechanic', 'Mechanic', 1);
