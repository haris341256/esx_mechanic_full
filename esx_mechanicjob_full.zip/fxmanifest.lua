
fx_version 'cerulean'
game 'gta5'

author 'YourName'
description 'Mekanik Job untuk FiveM'
version '1.0.0'

client_scripts {
    'client/main.lua'
}

server_scripts {
    'server/main.lua'
}

shared_scripts {
    '@es_extended/imports.lua'
}
