
# ESX Mechanic Job

This resource adds a mechanic job for FiveM servers, with features including:

- Vehicle repair and upgrades.
- Requesting a mechanic with a command.
- Mechanic job logs for bosses.
- Vehicle lifting simulation.
- Database structure for storing mechanic data.

## Installation Instructions

1. Download the entire folder into `resources/[esx]/esx_mechanicjob`.
2. Import the provided SQL file (`mechanicjob.sql`) into your database.
3. Add the following line to your `server.cfg`:
    ```
    start esx_mechanicjob
    ```
4. Restart your server and test the mechanic job.

## Features
- Repair vehicles and perform upgrades (engine, brakes, turbo, suspension).
- Boss can view mechanic job logs.
- Vehicle lifting simulation for immersive roleplay.
