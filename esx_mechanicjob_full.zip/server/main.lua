
ESX.RegisterServerCallback('esx_mechanicjob:getLogs', function(source, cb)
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer.job.name == 'mechanic' and xPlayer.job.grade_name == 'boss' then
        cb(mechanicLogs)
    else
        cb({})
    end
end)

RegisterServerEvent('esx_mechanicjob:requestMechanic')
AddEventHandler('esx_mechanicjob:requestMechanic', function(coords)
    local callerId = source
    for _, id in pairs(GetPlayers()) do
        local xPlayer = ESX.GetPlayerFromId(id)
        if xPlayer.job.name == 'mechanic' then
            TriggerClientEvent('esx_mechanicjob:receiveCall', id, callerId, coords)
        end
    end
end)

RegisterServerEvent('esx_mechanicjob:charge')
AddEventHandler('esx_mechanicjob:charge', function(amount)
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer.getMoney() >= amount then
        xPlayer.removeMoney(amount)
        xPlayer.showNotification("Rp"..amount.." telah dibayar.")
    else
        xPlayer.showNotification("Uangmu tidak cukup.")
    end
end)
